/*
 * Translated default messages for bootstrap-select.
 * Locale: CS
 * Region: CZ (Czech Republic)
 */
(function ($) {
  $.fn.selectpicker.defaults = {
    noneSelectedText: 'Nic není vybráno',
    noneResultsText: 'Žádné výsledky {0}',
    countSelectedText: 'Označeno {0} z {1}',
    maxOptionsText: ['Limit překročen ({n} {var} max)', 'Limit skupiny překročen ({n} {var} max)', ['položek', 'položka']],
    multipleSeparator: ', ',
    selectAllText: 'Vybrat Vše',
    deselectAllText: 'Odznačit Vše'
  };
})(jQuery);
